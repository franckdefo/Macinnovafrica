const menubtn = document.querySelector('#open-menu-btn')
const closeMenu = document.querySelector('#close-menu-btn')
const menu = document.querySelector('.nav_menu')

var swiper = new Swiper(".mySwiper", {
    pagination: {
      el: ".swiper-pagination",
      type: "progressbar",
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
  /*window.addEventListener('scroll',()=>{
    document.querySelector('nav').classList.toggle('window-scrolled',window.scrollY>0);
  })*/


// open nav menu
menubtn.addEventListener('click',()=>{
  menu.style.display ='block';
  closeMenu.style.display = 'inline-block';
  menubtn.style.display = 'none'
})

// close nav menu

closeMenu.addEventListener('click',()=>{
  menu.style.display ='none';
  closeMenu.style.display = 'none';
  menubtn.style.display = 'inline-block'
})